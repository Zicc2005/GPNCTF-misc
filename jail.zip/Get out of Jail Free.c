#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

static char *const envp[] = {"HOME=/home/jail1", "EDITRC=/home/jail1/.editrc", "PATH=/bin", 0};

int main() {
	if (chdir("/home/jail1")) {
		perror("chdir");
		exit(1);
	}
	if (setregid(1001, 1001)) { // jail1 user
		perror("setregid");
		exit(2);
	}
	if (setreuid(1001, 1001)) { // jail1 group
		perror("setreuid");
		exit(3);
	}

	execle("/usr/bin/dash", "dash", "-ECi", NULL, envp);
	perror("execl");
	exit(4);
}
