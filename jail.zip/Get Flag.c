#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
	char flag[1024] = {};

	if (setreuid(1002, 1002)) { // jail2 user
		perror("setreuid");
		exit(3);
	}

	int fd = open("/flag", O_RDONLY);
	if (fd == -1) {
		perror("open");
		exit(1);
	}
	if (read(fd, flag, sizeof flag - 1) == -1) {
		perror("read");
		exit(2);
	}

	puts(flag);
}
