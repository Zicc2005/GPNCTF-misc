#!/bin/sh
stty raw -echo
nc localhost 8458

